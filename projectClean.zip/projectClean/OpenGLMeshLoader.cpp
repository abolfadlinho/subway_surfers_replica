#include "TextureBuilder.h"
#include "Model_3DS.h"
#include "GLTexture.h"
#include <stdio.h>
#include <stdlib.h>
#include <glut.h>
#include <math.h>
#define _USE_MATH_DEFINES
#include <cstdlib> 
#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>
#include <string>
#include <Windows.h>
#include <mmsystem.h>
#include <thread>
#include <vector>
#include <algorithm>

#define GLUT_KEY_ESCAPE 27

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//game variables
bool  gameRunning = false;
int   score = 0;
int   level = 1;
float timeX  = 0.0;

std::string gameMessage = "";

float playerX   = 0.0f;
float playerZ   = 0.75f;
float playerY   = 0.0f;
bool  isJumping = false;
float maxY      = 1.7f;
float maxX      = 1.5f;
float minX      = -1.5f;
float speed     = 0.3f;

float leftCoinZ     = -3.0f;
float centreCoinZ   = -23.0;
float rightCoinZ    = -43.0;
float leftBlockZ    = -55.0f;
float centreBlockZ  = -35.0;
float rightBlockZ   = -75.0;
float leftHurdleZ   = -21.0f;
float centreHurdleZ = -41.0f;
float rightHurdleZ  = -61.0;

bool firstPerson = false;


Model_3DS ball;
Model_3DS ball2;
Model_3DS train;
Model_3DS rail;
Model_3DS hurdle;
Model_3DS coin;
Model_3DS building;
Model_3DS tunnel;
Model_3DS tunnel2;
Model_3DS trash;
Model_3DS diamond;
Model_3DS finish_line;
Model_3DS lamp;


GLTexture tex_ground;

GLdouble fovy = 45.0;
GLdouble aspectRatio = (GLdouble)480 / (GLdouble)740;
GLdouble zNear = 0.1;
GLdouble zFar = 120;

GLfloat lightColor[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat lightPosition[] = { 50.0f, 100.0f, 0.0f, 0.0f };
GLfloat lightIntensity[] = { 0.7, 0.7, 0.7, 1.0f };
GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };

GLuint tex;


class Vector
{
public:
	GLdouble x, y, z;
	Vector() {}
	Vector(GLdouble _x, GLdouble _y, GLdouble _z) : x(_x), y(_y), z(_z) {}
	void operator +=(float value)
	{
		x += value;
		y += value;
		z += value;
	}
};

Vector Eye(0, 8, 25);
Vector At(0, 0, 0);
Vector Up(0, 1, 0);

int cameraZoom = 0;

//Threads
void playBackground() {
	PlaySound(TEXT("Sounds/background.wav"), NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
}
void playCrash() {
	PlaySound(TEXT("Sounds/crash.wav"), NULL, SND_ASYNC | SND_FILENAME);
}
void playPoint() {
	PlaySound(TEXT("Sounds/point.wav"), NULL, SND_ASYNC | SND_FILENAME);
}

void InitLightSource()
{
	// Enable Lighting for this OpenGL Program
	glEnable(GL_LIGHTING);

	// Enable Light Source number 0
	// OpengL has 8 light sources
	glEnable(GL_LIGHT0);

	// Define Light source 0 ambient light
	GLfloat ambient[] = { 0.1f, 0.1f, 0.1, 1.0f };
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);

	// Define Light source 0 diffuse light
	GLfloat diffuse[] = { 0.5f, 0.5f, 0.5f, 1.0f };
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

	// Define Light source 0 Specular light
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

	// Finally, define light source 0 position in World Space
	//GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
}

void drawBlock(float x, float y, float z) {
	glPushMatrix();
	glTranslatef(x, y, z);
	glScalef(0.015f, 0.015, 0.015); //logic for scaling
	//glRotatef(90.0, 0.0, 1.0, 0.0); //logic for rotating
	train.Draw();
	glPopMatrix();
}

void drawHurdle(float x, float y, float z) {
	glPushMatrix();
	glTranslatef(x, y, z);
	if (x == 1.5f) glTranslatef(1.3f, 0.0f, 0.0f);
	if (x == -1.5f) glTranslatef(-1.3f, 0.0f, 0.0f);
	glScalef(0.005f, 0.01f, 0.01); //logic for scaling
	//glRotatef(90.0, 0.0, 1.0, 0.0); //logic for rotating
	if (level == 2) {
		glRotatef(90.0, 0.0, 1.0, 0.0);
		glScalef(0.6f, 0.3f, 1.0);
		trash.Draw();
	}
	else {
		hurdle.Draw();
	}
	glPopMatrix();
}

void drawCoin(float x, float z) {
	glPushMatrix();
	glTranslatef(x+0.15f , 1.5f, z);
	if (x == 1.5f) glTranslatef(1.3f, 0.0f, 0.0f);
	if (x == -1.5f) glTranslatef(-1.3f, 0.0f, 0.0f);
	glScalef(0.08f, 0.08f, 0.08f); //logic for scaling
	if (level == 2) {
		glRotatef(-timeX * 100, 0, 1, 0);
		glRotatef(90.0, 1.0, 0.0, 0.0); //logic for rotating
		coin.Draw();
	}
	else {
		glScalef(0.15f, 0.15f, 0.15f); //logic for scaling
		//glRotatef(90.0, 1.0, 0.0, 0.0);
		glRotatef(-timeX * 100, 0, 1, 0);
		diamond.Draw();
	}
	glPopMatrix();
	if (score == 19 || score == 39) {
		glPushMatrix();
		glTranslatef(x + 0.7f, 0.0, z + 0.5f);
		if (x == 1.5f) glTranslatef(1.3f, 0.0f, 0.0f);
		if (x == -1.5f) glTranslatef(-1.3f, 0.0f, 0.0f);
		glRotatef(90.0, 0.0, 1.0, 0.0);
		glScalef(0.05f, 0.15f, 0.15f);
		finish_line.Draw();
		glPopMatrix();
	}

}

void drawLeftHurdle(float z) {
	drawHurdle(-1.5f, 0.0f, z);
}
void drawCentreHurdle(float z) {
	drawHurdle(0.0f, 0.0f, z);
}
void drawRightHurdle(float z) {
	drawHurdle(1.5f, 0.0f, z);
}
void drawLeftBlock(float z) {
	drawBlock(-2.8f, 0.0f, z);
}
void drawCentreBlock(float z) {
	drawBlock(0.0f, 0.0f, z);
}
void drawRightBlock(float z) {
	drawBlock(2.8f, 0.0f, z);
}

void drawLeftWall() {
	glPushMatrix();
	glRotated(90, 0, 1.0, 0);
	glTranslated(0.5, 7, 8.0);
	glScaled(0.05, 0.05, 0.05);
	building.Draw();
	glPopMatrix();
}
void drawTunnel() {
	//TODO
	glPushMatrix();
	glRotated(-90, 0.0, 1.0, 0.0);
	glTranslated(-35.0, 0.0, 1.5);
	glScaled(0.1, 0.07, 0.025);
	tunnel.Draw();
	glPopMatrix();

	glPushMatrix();
	glRotated(-90, 0.0, 1.0, 0.0);
	glTranslated(-35.0, 0.0, -1.5);
	glScaled(0.1, 0.07, 0.025);
	tunnel2.Draw();
	glPopMatrix();
}
void drawRightWall() {
	glPushMatrix();
	glRotated(270, 0, 1.0, 0);
	glTranslated(0.5, 7, 8.0);
	glScaled(0.05, 0.05, 0.05);
	building.Draw();
	glPopMatrix();
}
void drawFloor() {
		glDisable(GL_LIGHTING);	// Disable lighting 

		glColor3f(0.6, 0.6, 0.6);	// Dim the ground texture a bit

		glEnable(GL_TEXTURE_2D);	// Enable 2D texturing

		glBindTexture(GL_TEXTURE_2D, tex_ground.texture[0]);	// Bind the ground texture

		glPushMatrix();
		glBegin(GL_QUADS);
		glNormal3f(0, 1, 0);	// Set quad normal direction.
		glTexCoord2f(0, 0);		// Set tex coordinates ( Using (0,0) -> (5,5) with texture wrapping set to GL_REPEAT to simulate the ground repeated grass texture).
		glVertex3f(-20, 0, -40);
		glTexCoord2f(5, 0);
		glVertex3f(20, 0, -40);
		glTexCoord2f(5, 5);
		glVertex3f(20, 0, 20);
		glTexCoord2f(0, 5);
		glVertex3f(-20, 0, 20);
		glEnd();
		glPopMatrix();

		glEnable(GL_LIGHTING);	// Enable lighting again for other entites coming throung the pipeline.

		glColor3f(1, 1, 1);	// Set material back to white instead of grey used for the ground texture.

	glPushMatrix();
	glScalef(0.08, 0.05, 0.57);
	glRotatef(90.0, 0.0, 1.0, 0.0);
	glPushMatrix();
	glTranslatef(0.0, -2.5, -35.0f);
	rail.Draw();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.0, -2.5, 0.0f);
	rail.Draw();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.0, -2.5, 35.0f);
	rail.Draw();
	glPopMatrix();
	glPopMatrix();
}
void drawLamp() {
	glPushMatrix();
	glTranslatef(-4.5, 0.0, 0.0);
	glScalef(1.0, 0.2, 0.0);
	lamp.Draw();
	glPopMatrix();

	GLfloat lightPosition2[] = { -4.5f, 1.0f, 0.0f, 1.0f };  // Position of the light source (adjust the Y value for height)
	GLfloat lightColor2[] = { 0.0f, 0.0f, 7.0f, 1.0f };  // Color of the light

	// Enable lighting and set light properties
	glEnable(GL_LIGHT1);  // Use a different light source index (e.g., GL_LIGHT1)
	glLightfv(GL_LIGHT1, GL_POSITION, lightPosition2);  // Set light position
	glLightfv(GL_LIGHT1, GL_DIFFUSE, lightColor2);
}

void setupScene() {
	drawLeftWall();
	drawRightWall();
	drawTunnel();
	drawFloor();
	drawLamp();
}

void drawPlayer() {
	glPushMatrix();
	glTranslatef(playerX, playerY+0.5, playerZ+12.0);
	if (playerX == 1.5f) glTranslatef(1.3f, 0.0, 0.0);
	if (playerX == -1.5f) glTranslatef(-1.3f, 0.0, 0.0);
	//glRotatef(180, 0, 1, 0);
	glRotatef(-timeX*100, 1, 0, 0);
	if (level == 2) {
		glScaled(0.005, 0.005, 0.005);
		ball.Draw();
	}
	else {
		glScaled(0.5, 0.5, 0.5);
		ball2.Draw();
	}
	glPopMatrix();
}

void resetGameVariables() {
	Eye.y = 8;
	Eye.z = 25;
	glLoadIdentity();	//Clear Model_View Matrix

	gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glutPostRedisplay();

	playerX = 0.0f;
	playerZ = 0.75f;
	playerY = 0.0f;
	isJumping = false;
	speed = 0.3f;

	leftCoinZ = -3.0f;
	centreCoinZ = -23.0;
	rightCoinZ = -43.0;
	leftBlockZ = -55.0f;
	centreBlockZ = -35.0;
	rightBlockZ = -75.0;
	leftHurdleZ = -21.0f;
	centreHurdleZ = -41.0f;
	rightHurdleZ = -61.0;

	level = 1;
	timeX = 0.0;

	lightColor[0] = 1.0f; lightColor[1] = 1.0f; lightColor[2] = 1.0f; lightColor[3] = 1.0f;
	lightPosition[0] = 50.0f; lightPosition[1] = 100.0f; lightPosition[2] = 0.0f; lightPosition[3] = 1.0f;
	lightIntensity[0] = 0.7f; lightIntensity[1] = 0.7f; lightIntensity[2] = 0.7f; lightIntensity[3] = 1.0f;
	light_position[0] = 0.0f; light_position[1] = 10.0f; light_position[2] = 0.0f; light_position[3] = 1.0f;

}
void gameOver() {
	gameRunning = false;

	// Request a scene update
	glutPostRedisplay();
	PlaySound(TEXT("Sounds/lose.wav"), NULL, SND_ASYNC | SND_FILENAME);
	gameMessage = "GAME OVER! Score: " + std::to_string(score) + ". Press SPACE to try again.";
	resetGameVariables();
}
void gameWon() {
	gameRunning = false;

	// Request a scene update
	glutPostRedisplay();
	PlaySound(TEXT("Sounds/win.wav"), NULL, SND_ASYNC | SND_FILENAME);
	gameMessage = "GAME WON! Score:" + std::to_string(score) + ". Press SPACE to play again."; // Convert score to string
	resetGameVariables();
}

void respawnObjects() {
	//spawn coins
	if (leftCoinZ > 18.0f) {
		//leftCoinZ = -3.0f;
		leftCoinZ = ((centreCoinZ > rightCoinZ) ? rightCoinZ : centreCoinZ) - 20.0f;
	}
	if (centreCoinZ > 18.0f) {
		//centreCoinZ = -3.5f;
		centreCoinZ = ((leftCoinZ > rightCoinZ) ? rightCoinZ : leftCoinZ) - 20.0f;
	}
	if (rightCoinZ > 18.0f) {
		//rightCoinZ = -4.0f;
		rightCoinZ = ((leftCoinZ > centreCoinZ) ? centreCoinZ : leftCoinZ) - 20.0f;
	}
	//spawn blocks
	if (centreBlockZ > 18.0f) {
		centreBlockZ = ((leftBlockZ > rightBlockZ) ? rightBlockZ : leftBlockZ) - 20.0f;
	}
	if (leftBlockZ > 18.0f) {
		leftBlockZ = ((centreBlockZ > rightBlockZ) ? rightBlockZ : centreBlockZ) - 20.0f;
	}
	if (rightBlockZ > 18.0f) {
		rightBlockZ = ((leftBlockZ > centreBlockZ) ? centreBlockZ : leftBlockZ) - 20.0f;
	}
	//spawn hurdles
	if (centreHurdleZ > 18.0f) {
		centreHurdleZ = ((leftHurdleZ > rightHurdleZ) ? rightHurdleZ : leftHurdleZ) - 20.0f;
	}
	if (leftHurdleZ > 18.0f) {
		leftHurdleZ = ((centreHurdleZ > rightHurdleZ) ? rightHurdleZ : centreHurdleZ) - 20.0f;
	}
	if (rightHurdleZ > 18.0f) {
		rightHurdleZ = ((leftHurdleZ > centreHurdleZ) ? centreHurdleZ : leftHurdleZ) - 20.0f;
	}
}
void handleJumping() {
	// jumping
	if (isJumping && playerY < maxY) {
		playerY += 0.1f;
		if (firstPerson) {
			Eye.y += 0.1f;
			glLoadIdentity();	//Clear Model_View Matrix

			gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

			glLightfv(GL_LIGHT0, GL_POSITION, light_position);

			glutPostRedisplay();
		}
	}
	else {
		if (playerY > 0.0f && !isJumping) {
			playerY -= 0.1f;
			if (firstPerson) {
				Eye.y -= 0.1f;
				glLoadIdentity();	//Clear Model_View Matrix

				gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

				glLightfv(GL_LIGHT0, GL_POSITION, light_position);

				glutPostRedisplay();
			}
		}
	}
	if (playerY >= maxY) {
		isJumping = false;
	}
}
void handleMovement() {}
void checkCollisions() {
	//check collisions with coins
	if (playerX == 0.0f && (std::abs(playerZ + 12.0 - centreCoinZ) < speed)) {
		score++;
		centreCoinZ = 23.9f;
		std::cout << "colided with coin" << std::endl;
		std::thread t3(playPoint);
		t3.detach();
		if (score == 20) {
			level = 2;
			speed *= 2;
			gameRunning = false;
			lightColor[0] = 1.0f; // Red
			lightColor[1] = 191.0f / 255.0f; // Green
			lightColor[2] = 55.0f / 255.0f; // Blue

			lightIntensity[0] = 0.1f; // Red
			lightIntensity[1] = 0.1f; // Green
			lightIntensity[2] = 0.1f; // Blue

			// Request a scene update
			glutPostRedisplay();
		}
		if (score == 40) {
			gameWon();
		}
	}
	if (playerX == -1.5f && (std::abs(playerZ + 12.0 - leftCoinZ) < speed)) {
		score++;
		leftCoinZ = 23.9f;
		std::cout << "colided with coin" << std::endl;
		std::thread t3(playPoint);
		t3.detach();
		if (score == 20) {
			level = 2;
			speed *= 2;
			gameRunning = false;
			lightColor[0] = 1.0f; // Red
			lightColor[1] = 191.0f / 255.0f; // Green
			lightColor[2] = 55.0f / 255.0f; // Blue

			lightIntensity[0] = 0.1f; // Red
			lightIntensity[1] = 0.1f; // Green
			lightIntensity[2] = 0.1f; // Blue

			// Request a scene update
			glutPostRedisplay();
		}
		if (score == 40) {
			gameWon();
		}
	}
	if (playerX == 1.5f && (std::abs(playerZ + 12.0 - rightCoinZ) < speed)) {
		score++;
		rightCoinZ = 23.9f;
		std::cout << "colided with coin" << std::endl;
		std::thread t3(playPoint);
		t3.detach();
		if (score == 20) {
			level = 2;
			speed *= 2;
			gameRunning = false;
			lightColor[0] = 1.0f; // Red
			lightColor[1] = 191.0f / 255.0f; // Green
			lightColor[2] = 55.0f / 255.0f; // Blue

			lightIntensity[0] = 0.1f; // Red
			lightIntensity[1] = 0.1f; // Green
			lightIntensity[2] = 0.1f; // Blue

			// Request a scene update
			glutPostRedisplay();
		}
		if (score == 40) {
			gameWon();
		}
	}
	//check collisions with blocks
	if (playerX == 0.0f && playerZ <= centreBlockZ - 7.0 && playerZ >= centreBlockZ - 15.0) {
		std::cout << "colided with block" << std::endl;
		centreBlockZ = ((leftBlockZ > rightBlockZ) ? rightBlockZ : leftBlockZ) - 20.0f;
		gameOver();
	}
	if (playerX == -1.5f && playerZ <= leftBlockZ - 7.0 && playerZ >= leftBlockZ - 15.0) {
		std::cout << "colided with block" << std::endl;
		leftBlockZ = ((centreBlockZ > rightBlockZ) ? rightBlockZ : centreBlockZ) - 20.0f;
		gameOver();
	}
	if (playerX == 1.5f && playerZ <= rightBlockZ - 7.0 && playerZ >= rightBlockZ - 15.0) {
		std::cout << "colided with block" << std::endl;
		rightBlockZ = ((leftBlockZ > centreBlockZ) ? centreBlockZ : leftBlockZ) - 20.0f;
		gameOver();
	}
	//check collisions with hurdles
	if (playerX == 0.0f && playerZ <= centreHurdleZ - 11.0 && playerZ >= centreHurdleZ - 15.0 && playerY < 0.5) {
		std::cout << "colided with hurdle" << std::endl;
		centreHurdleZ = ((leftHurdleZ > rightHurdleZ) ? rightHurdleZ : leftHurdleZ) - 20.0f;
		score--;
		std::thread t2(playCrash);
		t2.detach();
	}
	if (playerX == -1.5f && playerZ <= leftHurdleZ - 11.0 && playerZ >= leftHurdleZ - 15.0 && playerY < 0.5) {
		std::cout << "colided with hurdle" << std::endl;
		leftHurdleZ = ((centreHurdleZ > rightHurdleZ) ? rightHurdleZ : centreHurdleZ) - 20.0f;
		score--;
		std::thread t2(playCrash);
		t2.detach();
	}
	if (playerX == 1.5f && playerZ <= rightHurdleZ - 11.0 && playerZ >= rightHurdleZ - 15.0 && playerY < 0.5) {
		std::cout << "colided with hurdle" << std::endl;
		rightHurdleZ = ((leftHurdleZ > centreHurdleZ) ? centreHurdleZ : leftHurdleZ) - 20.0f;
		score--;
		std::thread t2(playCrash);
		t2.detach();
	}
}
void moveObjects() {
	leftCoinZ += speed;
	centreCoinZ += speed;
	rightCoinZ += speed;
	leftBlockZ += speed;
	centreBlockZ += speed;
	rightBlockZ += speed;
	leftHurdleZ += speed;
	centreHurdleZ += speed;
	rightHurdleZ += speed;
}
void renderText(const char* text, float x, float y) {
	// Save the current projection matrix
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(-1.0, 1.0, -1.0, 1.0); // Set orthographic projection for text rendering

	// Save the model-view matrix
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	// Render the text
	glColor3f(0.0f, 0.0f, 0.0f); // White color for text
	glRasterPos2f(x, y);         // Set text position
	for (const char* c = text; *c != '\0'; ++c) {
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
	}
	char* text2 = "Press SPACE to start the game";
	if (!gameRunning && score != 20) {
		glRasterPos2f(x-0.3, y-0.05f);         // Set text position
		for (const char* c2 = text2; *c2 != '\0'; ++c2) {
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c2);
		}
	}
	char* text4 = "Press SPACE to start Level 2.";
	if (!gameRunning && score == 20) {
		glRasterPos2f(x - 0.3, y - 0.05f);         // Set text position
		for (const char* c4 = text4; *c4 != '\0'; ++c4) {
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c4);
		}
	}
	std::string scoreString = "Score: " + std::to_string(score); // Construct the score string
	const char* score = scoreString.c_str(); // Convert to const char* if required
	if (gameRunning) {
		glRasterPos2f(x + 0.05, y - 0.05f); // Set text position
		for (const char* c3 = score; *c3 != '\0'; ++c3) {
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c3); // Render each character
		}
	}
	glColor3f(1.0f, 1.0f, 1.0f);
	// Restore the model-view matrix
	glPopMatrix();

	// Restore the projection matrix
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	// Return to model-view matrix mode
	glMatrixMode(GL_MODELVIEW);
}
void updateLightPosition() {
	// Use timeX to calculate the light's position in circular motion
	lightPosition[0] = 50.0f * cos(timeX); // X-coordinate
	lightPosition[2] = 50.0f * sin(timeX); // Z-coordinate

	// Apply the updated light position
	glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
}

void timer(int) {
	if (gameRunning) {
		timeX += 0.1f;

		if (timeX >= 2 * M_PI) timeX -= 2 * M_PI;
		updateLightPosition();

		moveObjects();
		respawnObjects();

		handleJumping();

		checkCollisions();
	}

	glutPostRedisplay();
	glutTimerFunc(20, timer, 0);
}

void Display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightIntensity);


	setupScene();

	drawPlayer();
	drawCentreBlock(centreBlockZ);
	drawLeftBlock(leftBlockZ);
	drawRightBlock(rightBlockZ);
	drawCoin(1.5, rightCoinZ);
	drawCoin(-1.5, leftCoinZ);
	drawCoin(0.0, centreCoinZ);
	drawLeftHurdle(leftHurdleZ);
	drawCentreHurdle(centreHurdleZ);
	drawRightHurdle(rightHurdleZ);


	glPushMatrix();

	GLUquadricObj* qobj;
	qobj = gluNewQuadric();
	glTranslated(50, 0, 0);
	glRotated(90, 1, 0, 1);
	glBindTexture(GL_TEXTURE_2D, tex);
	gluQuadricTexture(qobj, true);
	gluQuadricNormals(qobj, GL_SMOOTH);
	gluSphere(qobj, 100, 100, 100);
	gluDeleteQuadric(qobj);


	glPopMatrix();

	renderText("Urban Runner", -0.22f, 0.9f);

	if (!gameMessage.empty()) {
		if (gameMessage.find("GAME WON!") != std::string::npos) {
			glClearColor(0.0f, 7.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glColor3f(0.0f, 0.0f, 0.0f); // Set text color to green for "Game Won!"
		}
		else {
			glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glColor3f(7.0f, 0.0f, 0.0f); // Set text color to red for other messages
		}

		glRasterPos2f(-6.0f, 0.0f); // Position the text in the center

		for (const char& c : gameMessage) {
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c); // Draw each character
		}
	}
	glutSwapBuffers();
}

// hamada
void Keyboard(unsigned char key, int x, int y) {
	float d = 0.01;
	//GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
	switch (key) {
	case 'w':
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		break;
	case 'r':
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		break;
	case 'z':  // Side view
		if (gameRunning) {
			firstPerson = true;
			Eye.y = 1;
			Eye.z = 12;
			glLoadIdentity();	//Clear Model_View Matrix

			gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

			glLightfv(GL_LIGHT0, GL_POSITION, light_position);

			glutPostRedisplay();
		}
		break;
	case 'x':  // Side view
		if (gameRunning) {
			firstPerson = false;
			Eye.y = 8;
			Eye.z = 25;
			glLoadIdentity();	//Clear Model_View Matrix

			gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

			glLightfv(GL_LIGHT0, GL_POSITION, light_position);

			glutPostRedisplay();
		}
		break;
	case '=':
		if (gameRunning && playerX < 1.5) {
			playerX += 1.5f;
			if (firstPerson) {
				Eye.x += 2.8f;
				At.x += 2.8f;
				glLoadIdentity();	//Clear Model_View Matrix

				gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

				glLightfv(GL_LIGHT0, GL_POSITION, light_position);

				glutPostRedisplay();
			}
		}
		break;
	case '-':
		if (gameRunning && playerX > -1.5) {
			playerX -= 1.5f;
			if (firstPerson) {
				Eye.x -= 2.8f;
				At.x -= 2.8f;

				glLoadIdentity();	//Clear Model_View Matrix

				gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

				glLightfv(GL_LIGHT0, GL_POSITION, light_position);

				glutPostRedisplay();
			}
		}
		break;
	case ' ':
		if (!gameRunning) {
			gameRunning = true;
			if (!gameMessage.empty()) {
				gameMessage = "";
				score = 0;
			}
		}
		else {
			if (!isJumping) {
				isJumping = true;
			}
		}
		break;
	case GLUT_KEY_ESCAPE:
		exit(EXIT_SUCCESS);
		break;
	}

	glutPostRedisplay();
}

void Motion(int x, int y)
{
	y = 740 - y;

	if (cameraZoom - y > 0)
	{
		Eye.z += -0.1;
	}
	else
	{
		if(Eye.z < 30) Eye.z += 0.1;
	}

	cameraZoom = y;

	glLoadIdentity();	//Clear Model_View Matrix

	gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

	//GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glutPostRedisplay();	//Re-draw scene 
}
void Mouse(int button, int state, int x, int y)
{
	y = 740 - y;

	if (state == GLUT_DOWN)
	{
		cameraZoom = y;
		if (button == GLUT_LEFT_BUTTON)
		{
			if (gameRunning && playerX > -1.5) {
				playerX -= 1.5f;
				if (firstPerson) {
					Eye.x -= 2.8f;
					At.x -= 2.8f;

					glLoadIdentity();	//Clear Model_View Matrix

					gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

					glLightfv(GL_LIGHT0, GL_POSITION, light_position);

					glutPostRedisplay();
				}
			}
		}
		else if (button == GLUT_RIGHT_BUTTON)
		{
			if (gameRunning && playerX < 1.5) {
				playerX += 1.5f;
				if (firstPerson) {
					Eye.x += 2.8f;
					At.x += 2.8f;
					glLoadIdentity();	//Clear Model_View Matrix

					gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

					glLightfv(GL_LIGHT0, GL_POSITION, light_position);

					glutPostRedisplay();
				}
			}
		}
	}
}
void Reshape(int w, int h) {
	if (h == 0) {
		h = 1;
	}

	// set the drawable region of the window
	glViewport(0, 0, w, h);

	// set up the projection matrix 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fovy, (GLdouble)w / (GLdouble)h, zNear, zFar);

	// go back to modelview matrix so we can move the objects about
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);

}


void InitMaterial()
{
	// Enable Material Tracking
	glEnable(GL_COLOR_MATERIAL);

	// Sich will be assigneet Material Properties whd by glColor
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	// Set Material's Specular Color
	// Will be applied to all objects
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);

	// Set Material's Shine value (0->128)
	GLfloat shininess[] = { 96.0f };
	glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
}
void LoadAssets()
{
	 
	//train
	train.Load("Models/imported/train2/Locomotive TGM3 N120711.3DS"); //shaghala textured


	//fence
	hurdle.Load("Models/imported/fence/Fence N130912.3DS"); //shaghala textured

	//coin
	coin.Load("Models/imported/coin/Coin 1.3DS"); //shaghala textured


	//diamond
	diamond.Load("Models/imported/diamond/Mirror Visionnaire Forma Mentis N251119.3ds");
	
	
	//lamp
	lamp.Load("Models/imported/lamp/Lamppost N131219.3ds");


	//building
	building.Load("Models/imported/building/Building 9-storey N121121.3ds"); //shaghala textured

	
	//ball
	ball.Load("Models/imported/ball/Basketball Molten N221222.3ds"); //shaghala textured
	ball2.Load("Models/imported/Pallone/Ball 3DS.3ds"); //shaghala not textured


	//trash
	trash.Load("Models/imported/trash/Trash box N240315.3DS");


	//tunnel
	tunnel.Load("Models/imported/bridge/Bridge Ponte De Tijolos N250515.3DS");
	tunnel2.Load("Models/imported/bridge/Bridge Ponte De Tijolos N250515.3DS");


	//rail
	rail.Load("Models/imported/grill/Convector grill floor radiator N081220.3ds"); //shaghala textured
	//model_tree.Load("Models/imported/rail/arch_bridge^.3DS"); //shaghala not textured


	//finish line
	finish_line.Load("Models/imported/finishline/120512_fence_museum_barrier_rope.3DS");


	// Loading texture files for sky and ground
	tex_ground.Load("Textures/grass.bmp");
	loadBMP(&tex, "Textures/blu-sky-3.bmp", true);
}

void init() {
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fovy, aspectRatio, zNear, zFar);
	//*******************************************************************************************//
	// fovy:			Angle between the bottom and top of the projectors, in degrees.			 //
	// aspectRatio:		Ratio of width to height of the clipping plane.							 //
	// zNear and zFar:	Specify the front and back clipping planes distances from camera.		 //
	//*******************************************************************************************//
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);
	InitLightSource();
	InitMaterial();
	LoadAssets();
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
}

void runPythonScript() {
	system("\python script.py");
}

void main(int argc, char** argv)
{
	std::thread pythonThread(runPythonScript);
	pythonThread.detach();

	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(480, 740);

	glutInitWindowPosition(500, 50);

	glutCreateWindow("Urban Runner");

	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutMotionFunc(Motion);
	glutMouseFunc(Mouse);
	glutReshapeFunc(Reshape);

	init();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);

	glShadeModel(GL_SMOOTH);
	glutTimerFunc(0, timer, 0);
	glutMainLoop();
}